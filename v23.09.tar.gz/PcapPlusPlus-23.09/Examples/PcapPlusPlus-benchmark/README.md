PcapPlusPlus Benchmark
======================

This is a benchmark application used for measuring PcapPlusPlus performance. It is based on Matias Fontanini's packet-capture-benchmarks project (https://github.com/mfontanini/packet-capture-benchmarks).

See this page for more details: https://pcapplusplus.github.io/docs/benchmark

This application currently compiles on Linux only (where benchmark was running on)
